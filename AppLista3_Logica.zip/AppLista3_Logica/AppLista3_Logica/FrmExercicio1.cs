﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3_Logica
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }



        private void btnMedia_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela

            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float media;
            //Calcular Media
            media = (num1 + num2 + num3) / 3;
            MessageBox.Show("Média é:" + media);
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            //Pegar os valores na Tela
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float soma;
            //Calcular Soma
            soma = (num1 + num2 + num3);
            MessageBox.Show("A soma é:" + soma);
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            //Pegar os valores na Tela
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float prct1, prct2, prct3;
            //Calcular Porcentagem
            prct1 = num1 / (num1 + num2 + num3) * 100;
            prct2 = num2 / (num1 + num2 + num3) * 100;
            prct3 = num3 / (num1 + num2 + num3) * 100;
            MessageBox.Show("a porcentagem é: " + prct1);
            MessageBox.Show("a porcentagem é: " + prct2);
            MessageBox.Show("a porcentagem é: " + prct3);
        }
    }
}

